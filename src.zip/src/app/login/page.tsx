import { LoginForm } from '@/src/components/auth/LoginForm';

import styles from './page.module.scss'

export default function LoginPage() {
    return (
        <main className={styles.login}>
            <LoginForm/>
        </main>
    )
}